
# Thrall's Changelog

All notable changes to Thrall will be documented in this file.

## [1.0.3] - 2024-08-23

### Added

-   Ability to change all Thrall related keybinds

### Changed

-   README.md

## [1.0.2] - 2024-08-23

### Added

-   Added text chat communication with Thrall (type in Valheim chat).
-   Ability to change menu keybinds

### Changed

-   Resource harvesting logic (experimental)

### Fixed

-   Logging cleanup