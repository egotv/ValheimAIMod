
# Thrall's Changelog

All notable changes to Thrall will be documented in this file.

## [1.0.2] - 2024-08-23

### Added

-   Added text chat communication with Thrall (type in Valheim chat).
-   Ability to change menu keybinds

### Changed

-   Resource harvesting logic

### Fixed

-   Logging cleanup